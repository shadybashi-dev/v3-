/* Group order planner: people, appetite and pizza size in, a pizza count out. */
(() => {
  'use strict';
  const MAX_GUESTS = 100;
  const SIZES = [28, 24, 18, 16];
  // A 16-inch pizza feeds 3 regular or 2 hungry eaters; other sizes scale by area.
  const PER_PERSON = {regular: Math.PI * 64 / 3, hungry: Math.PI * 64 / 2};
  const PHOTOS = ['pepperoni', 'special', 'supreme', 'margherita', 'hawaiian', 'mediterranean'];
  const SHOWN = 24;
  const area = inches => Math.PI * (inches / 2) ** 2;

  // Returns pizzas largest first, e.g. [{size:28,count:2},{size:24,count:1}].
  function plan(guests, appetite, size) {
    const need = guests * (PER_PERSON[appetite] || PER_PERSON.regular);
    if (SIZES.includes(size)) return [{size, count: Math.ceil(need / area(size) - 1e-9)}];
    // Mixed sizes: the fewest boxes with the least spare pizza, biggest pies preferred.
    let best = null;
    const most28 = Math.ceil(need / area(28));
    for (let a = 0; a <= most28; a++) for (let b = 0; b <= 3; b++) for (let c = 0; c <= 3; c++) for (let d = 0; d <= 3; d++) {
      const counts = [a, b, c, d];
      const total = counts.reduce((sum, count, i) => sum + count * area(SIZES[i]), 0);
      if (total + 1e-9 < need) continue;
      const pies = a + b + c + d;
      const cost = total - need + pies * 150;
      if (!best || cost < best.cost - 1e-9 || (Math.abs(cost - best.cost) < 1e-9 && a > best.counts[0])) best = {cost, counts};
    }
    return best.counts.map((count, i) => ({size: SIZES[i], count})).filter(row => row.count);
  }
  const feeds = (rows, appetite) => Math.floor(rows.reduce((sum, row) => sum + row.count * area(row.size), 0) / (PER_PERSON[appetite] || PER_PERSON.regular) + 1e-9);
  const pieCount = rows => rows.reduce((sum, row) => sum + row.count, 0);
  const describe = rows => {
    const parts = rows.map(row => row.count + ' × ' + row.size + '-inch');
    const list = parts.length > 1 ? parts.slice(0, -1).join(', ') + ' and ' + parts.at(-1) : parts[0];
    return list + (pieCount(rows) === 1 ? ' pizza' : ' pizzas');
  };

  if (typeof module === 'object' && module.exports) module.exports = {plan, feeds, describe, MAX_GUESTS};
  if (typeof document === 'undefined') return;

  const planner = document.querySelector('[data-party-planner]');
  if (!planner) return;
  const input = planner.querySelector('[data-party-guests]');
  const steps = Array.from(planner.querySelectorAll('[data-party-step]'));
  const result = planner.querySelector('[data-party-result]');
  const order = planner.querySelector('[data-party-order]');
  const visual = planner.querySelector('[data-party-pizzas]');
  const hint = planner.querySelector('[data-party-hint]');
  const limit = planner.querySelector('[data-party-limit]');
  const choice = name => planner.querySelector('input[name="' + name + '"]:checked')?.value;

  function update() {
    const typed = Math.round(Number(input.value));
    const guests = Math.min(MAX_GUESTS, Math.max(1, typed || 1));
    const appetite = choice('party-appetite') || 'regular';
    const size = choice('party-size') === 'mix' ? 'mix' : Number(choice('party-size'));
    const rows = plan(guests, appetite, size);
    steps.forEach(button => {button.disabled = Number(button.dataset.partyStep) < 0 ? guests <= 1 : guests >= MAX_GUESTS;});
    if (limit) limit.hidden = !(typed > MAX_GUESTS);

    result.textContent = 'For ' + guests + ' ' + (guests === 1 ? 'person' : 'people') + ', order ' + describe(rows) + '. Feeds about ' + feeds(rows, appetite) + '.';
    order.replaceChildren(...rows.map(row => {
      const chunk = document.createElement('span'), count = document.createElement('b');
      count.textContent = row.count;
      chunk.append(count, ' × ' + row.size + '"');
      return chunk;
    }));

    // Picking one smaller size can mean a stack of boxes; point out the bigger-pie option.
    const mixed = plan(guests, appetite, 'mix');
    if (hint) {
      const fewer = size !== 'mix' && pieCount(mixed) < pieCount(rows);
      hint.hidden = !fewer;
      if (fewer) hint.querySelector('[data-party-hint-text]').textContent = 'Fewer boxes, same crowd: ' + describe(mixed) + '.';
    }

    const wanted = rows.flatMap(row => Array(row.count).fill(row.size));
    const added = [];
    if (visual) {
      // Big orders get smaller pies so the whole order stays in view.
      const shown = Math.min(wanted.length, SHOWN);
      visual.style.setProperty('--pie-max', (shown <= 4 ? 110 : shown <= 8 ? 92 : shown <= 16 ? 70 : 54) + 'px');
      const pies = Array.from(visual.querySelectorAll('img'));
      wanted.slice(0, SHOWN).forEach((inches, index) => {
        let image = pies[index];
        if (!image) {
          image = document.createElement('img');
          image.src = 'assets/img/pizza-picker/' + PHOTOS[index % PHOTOS.length] + '-256.webp';
          image.alt = '';
          image.width = 96;
          image.height = 96;
          image.decoding = 'async';
          visual.append(image);
        }
        if (image.dataset.size !== String(inches)) {
          image.dataset.size = String(inches);
          image.style.setProperty('--d', inches);
          added.push(image);
        }
      });
      pies.slice(Math.min(wanted.length, SHOWN)).forEach(image => image.remove());
      let more = visual.querySelector('.party-more');
      if (wanted.length > SHOWN) {
        if (!more) {more = document.createElement('span'); more.className = 'party-more';}
        more.textContent = '+' + (wanted.length - SHOWN);
        visual.append(more);
      } else more?.remove();
    }
    document.dispatchEvent(new CustomEvent('antonia:party-update', {detail: {added}}));
  }

  steps.forEach(button => button.addEventListener('click', () => {
    const current = Math.min(MAX_GUESTS, Math.max(1, Math.round(Number(input.value)) || 1));
    input.value = String(Math.min(MAX_GUESTS, Math.max(1, current + Number(button.dataset.partyStep))));
    update();
  }));
  input.addEventListener('input', update);
  input.addEventListener('change', () => {
    const value = Math.min(MAX_GUESTS, Math.max(1, Math.round(Number(input.value)) || 1));
    if (input.value !== String(value) && Number(input.value) <= MAX_GUESTS) input.value = String(value);
    update();
  });
  planner.addEventListener('change', event => {if (event.target.type === 'radio') update();});
  hint?.querySelector('button')?.addEventListener('click', () => {
    const mix = planner.querySelector('input[name="party-size"][value="mix"]');
    mix.checked = true;
    mix.focus();
    update();
  });
  planner.hidden = false;
  update();
})();
