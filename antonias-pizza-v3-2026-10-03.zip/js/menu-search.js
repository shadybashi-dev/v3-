/* Progressive menu search: all dishes remain visible without JavaScript. */
(() => {
  'use strict';
  const panel = document.querySelector('[data-menu-search]');
  if (!panel) return;
  const input = panel.querySelector('input');
  const clear = panel.querySelector('button');
  const status = panel.querySelector('[role="status"]');
  const empty = document.querySelector('[data-menu-empty]');
  const normalize = value => value.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
  const sections = Array.from(document.querySelectorAll('.menu-section')).map(section => ({
    section,
    items: Array.from(section.querySelectorAll('.menu-item')).map(item => ({item, text: normalize(item.textContent)})),
    heading: normalize(section.querySelector('.head')?.textContent || '')
  }));
  const total = sections.reduce((sum, section) => sum + section.items.length, 0);
  function update() {
    const query = normalize(input.value);
    const terms = query.split(/\s+/).filter(Boolean);
    let matches = 0;
    const revealed=[];
    sections.forEach(({section, items, heading}) => {
      let visible = 0;
      items.forEach(({item, text}) => {
        const match = terms.every(term => (heading + ' ' + text).includes(term));
        if(match&&item.hidden)revealed.push(item);
        item.hidden = !match;
        if (match) visible++;
      });
      section.hidden = visible === 0;
      section.querySelectorAll('.dish-grid,.menu-item--feature').forEach(element => {element.hidden = !!query;});
      matches += visible;
    });
    clear.disabled = !input.value;
    empty.hidden = matches !== 0;
    status.textContent = query ? matches + (matches === 1 ? ' dish found' : ' dishes found') : total + ' dishes to explore';
    document.dispatchEvent(new CustomEvent('antonia:menu-results',{detail:{revealed,empty:matches===0?empty:null}}));
  }
  input.addEventListener('input', update);
  function reset() {input.value = ''; update(); input.focus();}
  clear.addEventListener('click', reset);
  input.addEventListener('keydown', event => {if (event.key === 'Escape') reset();});
  document.querySelectorAll('.menu-chip').forEach(chip => chip.addEventListener('click', () => {
    if (input.value) {input.value = ''; update();}
  }));
  panel.hidden = false;
  const requestedDish = new URLSearchParams(location.search).get('q');
  if (requestedDish) input.value = requestedDish.slice(0, 120);
  update();
})();
