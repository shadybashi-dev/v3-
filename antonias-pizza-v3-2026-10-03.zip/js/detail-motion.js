/* Finite, progressive motion. Content never depends on animation to appear. */
(() => {
  'use strict';
  const root=document.documentElement;
  const media=matchMedia('(prefers-reduced-motion: reduce)');
  const active=new Set(),seen=new WeakSet();
  const allowed=()=>!media.matches&&!root.classList.contains('reduce-motion')&&!root.classList.contains('motion-paused')&&!document.hidden;
  const selectors='.logo-badge,.section-head .eyebrow,.section-head h2,.section-head .lead,.menu-item,.menu-category-photo,.craving-card,.info-card,.faq-item,.review-card,.deal-mini,.party-planner,.saved-dishes,.footer-grid>div,.gallery-track figure,.step-img img,.dish-card img,.deal-card img,.visit-grid article';
  function play(element,frames,options={}){
    if(!allowed()||!element.animate||!element.isConnected)return;
    const animation=element.animate(frames,{duration:480,easing:'cubic-bezier(.2,.75,.25,1)',...options});
    active.add(animation);
    animation.finished.then(()=>active.delete(animation),()=>active.delete(animation));
    return animation;
  }
  function stop(){if(!allowed()){active.forEach(animation=>animation.cancel());active.clear();}}
  document.addEventListener('motionchange',stop);media.addEventListener('change',stop);document.addEventListener('visibilitychange',stop);
  const observer='IntersectionObserver' in window?new IntersectionObserver(entries=>{
    entries.forEach(entry=>{
      if(!entry.isIntersecting)return;
      observer.unobserve(entry.target);
      if(root.classList.contains('menu-motion-owned')&&entry.target.matches?.('.menu-item'))return;
      if(entry.target.querySelector?.('.legacy-word'))return;
      const index=Number(entry.target.dataset.motionIndex)||0;
      const photo=entry.target.matches?.('img,.gallery-track figure');
      play(entry.target,photo?[{opacity:.25,scale:'.88',translate:'0 24px'},{opacity:1,scale:'1',translate:'0 0'}]:[{opacity:.25,translate:'0 28px'},{opacity:1,translate:'0 0'}],{delay:Math.min(index,4)*75,duration:photo?750:560});
    });
  },{threshold:.12}):null;
  function scan(container){
    const targets=[];
    if(container.matches?.(selectors))targets.push(container);
    if(container.querySelectorAll)targets.push(...container.querySelectorAll(selectors));
    targets.forEach(element=>{
      if(seen.has(element))return;seen.add(element);
      element.dataset.motionIndex=Array.from(element.parentElement?.children||[]).indexOf(element);
      if(observer)observer.observe(element);
    });
  }
  scan(document);
  let navWasOpen=false;
  if('MutationObserver' in window)new MutationObserver(records=>{
    records.forEach(record=>{
      if(record.type==='attributes'&&record.target===document.body){
        const open=document.body.classList.contains('nav-open');
        if(open&&!navWasOpen)document.querySelectorAll('.nav-links a').forEach((link,index)=>play(link,[{opacity:0,translate:'0 18px'},{opacity:1,translate:'0 0'}],{delay:index*55,duration:400}));
        navWasOpen=open;return;
      }
      record.addedNodes.forEach(node=>{if(node.nodeType===1)scan(node);});
      // Brief feedback when a result or favorites message changes.
      const status=record.target.nodeType===1?record.target.closest?.('[role="status"]'):record.target.parentElement?.closest?.('[role="status"]');
      if(status&&!status.classList.contains('sr-only'))play(status,[{opacity:.5,translate:'0 4px'},{opacity:1,translate:'0 0'}],{duration:260});
    });
  }).observe(document.body,{childList:true,subtree:true,characterData:true,attributes:true,attributeFilter:['class']});
  document.addEventListener('click',event=>{
    const button=event.target.closest?.('button,.btn');
    if(!button||button.disabled||!allowed())return;
    // Individual scale composes with the existing wheel and button transforms.
    play(button,[{scale:'1'},{scale:'.96'},{scale:'1'}],{duration:210});
    if(button.matches('.btn,.craving-filters button,.wheel-btn,.back-to-top')){
      const rect=button.getBoundingClientRect(),ripple=document.createElement('span');
      ripple.className='motion-ripple';ripple.setAttribute('aria-hidden','true');
      const size=Math.max(rect.width,rect.height)*2;
      const x=event.detail?event.clientX-rect.left:rect.width/2,y=event.detail?event.clientY-rect.top:rect.height/2;
      ripple.style.cssText='width:'+size+'px;height:'+size+'px;left:'+(x-size/2)+'px;top:'+(y-size/2)+'px';
      button.append(ripple);
      const animation=play(ripple,[{scale:'.1',opacity:.3},{scale:'1',opacity:0}],{duration:520});
      if(animation)animation.finished.then(()=>ripple.remove(),()=>ripple.remove());else ripple.remove();
    }
    if(button.closest('.faq-item')&&button.getAttribute('aria-expanded')==='true'){
      const panel=document.getElementById(button.getAttribute('aria-controls'));
      if(panel&&!panel.hidden)play(panel,[{opacity:.3,translate:'0 -6px'},{opacity:1,translate:'0 0'}],{duration:300});
    }
    if(button.matches('[data-save]'))play(button,[{scale:'1'},{scale:'1.09'},{scale:'1'}],{duration:300});
    if(button.matches('.loc-tabs button')){
      const panel=document.getElementById(button.getAttribute('aria-controls'));
      if(panel&&!panel.hidden)play(panel,[{opacity:.5,translate:'0 10px'},{opacity:1,translate:'0 0'}],{duration:380});
    }
  });
})();
