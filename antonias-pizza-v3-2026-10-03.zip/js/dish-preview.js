/* Menu details use the menu's own copy and only dish-specific photographs. */
(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else api.init(root.document, root);
})(typeof window !== 'undefined' ? window : globalThis, function () {
  'use strict';

  const images = Object.freeze({
    "antonia's special": 'assets/img/pizza-picker/special.webp',
    'original margherita': 'assets/img/pizza-picker/margherita.webp',
    'deluxe supreme': 'assets/img/pizza-picker/supreme.webp',
    hawaiian: 'assets/img/pizza-picker/hawaiian.webp',
    mediterranean: 'assets/img/pizza-picker/mediterranean.webp',
    'ajarski original': 'assets/img/menu-cutouts/ajarski-960.webp',
    'caesar salad': 'assets/img/menu-cutouts/salad-960.webp',
    'spaghetti & meatballs': 'assets/img/menu-cutouts/pasta-960.webp',
    'classic wings': 'assets/img/menu-cutouts/wings-960.webp',
    'cheese steak': 'assets/img/menu-cutouts/cheesesteak-v2-960.webp',
    tiramisu: 'assets/img/menu-cutouts/tiramisu-960.webp'
  });

  function normalize(value) {
    return String(value || '').normalize('NFKC').replace(/[’‘]/g, "'").replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function slug(value) {
    return normalize(value).normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/'/g, '').replace(/&/g, ' and ').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  }

  function fullDescriptions(rows) {
    const descriptions = new Map();
    rows.forEach(row => {
      const key = normalize(row.name), previous = descriptions.get(key);
      if (!previous || row.description.length > previous.description.length) descriptions.set(key, row);
    });
    return descriptions;
  }

  function resolveDish(row, descriptions) {
    const exact = descriptions.get(normalize(row.name));
    return {
      ...row,
      description: row.featured && exact ? exact.description : row.description,
      shareName: exact ? exact.name : row.name,
      key: slug(exact ? exact.name : row.name),
      image: images[normalize(row.name)] || null
    };
  }

  function shareUrl(base, dish) {
    const url = new URL('menu.html', base);
    url.search = '';
    url.hash = dish.section || '';
    url.searchParams.set('q', dish.shareName);
    url.searchParams.set('dish', dish.key);
    return url.href;
  }

  async function shareDish(navigator = {}, data) {
    let canShare = typeof navigator.share === 'function';
    if (canShare && typeof navigator.canShare === 'function') {
      try { canShare = navigator.canShare(data); } catch (_) { canShare = false; }
    }
    if (canShare) {
      try {
        await navigator.share(data);
        return { method: 'shared', message: 'Dish shared.' };
      } catch (error) {
        if (error && error.name === 'AbortError') return { method: 'canceled', message: 'Sharing canceled.' };
      }
    }
    try {
      if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function') {
        await navigator.clipboard.writeText(data.url);
        return { method: 'copied', message: 'Dish link copied. Ready to share.' };
      }
    } catch (_) { /* Keep a selectable link available when clipboard permission is unavailable. */ }
    return { method: 'manual', message: 'Select and copy the dish link below.', url: data.url };
  }

  function init(document, win) {
    if (!document || !win) return null;
    const dialog = document.createElement('dialog');
    // The complete menu stays available in browsers without native modal dialogs.
    if (typeof dialog.showModal !== 'function') return null;
    if (document.getElementById('dish-preview')) return null;
    const root = document.documentElement;
    const media = typeof win.matchMedia === 'function' ? win.matchMedia('(prefers-reduced-motion: reduce)') : null;
    const allowed = () => !media?.matches && !root.classList.contains('reduce-motion') && !root.classList.contains('motion-paused') && !document.hidden;
    const clean = element => element ? element.textContent.replace(/\s+/g, ' ').trim() : '';
    const sectionFor = element => element.closest('.menu-section');
    const read = (element, featured) => {
      const section = sectionFor(element);
      return {
        element, featured,
        name: clean(element.querySelector(featured ? 'h3' : '.mi-name')),
        description: clean(element.querySelector(featured ? 'p' : '.mi-desc')),
        category: clean(section?.querySelector('.head h2')),
        section: section?.id || ''
      };
    };
    const rows = Array.from(document.querySelectorAll('.menu-item')).map(element => read(element, false)).filter(row => row.name);
    const descriptions = fullDescriptions(rows);
    const featured = Array.from(document.querySelectorAll('.dish-card .dish-body')).map(element => read(element, true)).filter(row => row.name);
    const dishes = [...rows, ...featured].map(row => resolveDish(row, descriptions));
    if (!dishes.length) return null;

    dialog.id = 'dish-preview';
    dialog.className = 'dish-preview';
    dialog.setAttribute('aria-labelledby', 'dish-preview-title');
    dialog.setAttribute('aria-describedby', 'dish-preview-description');
    dialog.innerHTML = '<button type="button" class="dish-preview__close" aria-label="Close dish details"><span aria-hidden="true">×</span></button>' +
      '<div class="dish-preview__layout"><div class="dish-preview__visual"><img width="960" height="960" decoding="async" alt=""></div>' +
      '<div class="dish-preview__content"><span class="dish-preview__category"></span><h2 id="dish-preview-title"></h2>' +
      '<p class="dish-preview__description" id="dish-preview-description"></p>' +
      '<div class="dish-preview__actions"><a class="dish-preview__order" href="https://antoniaspizza.toast.site/" target="_blank" rel="noopener">Order online <span aria-hidden="true">↗</span></a>' +
      '<button type="button" class="dish-preview__share">Share dish</button></div>' +
      '<div class="dish-preview__locations"><h3>Choose your restaurant</h3><a href="san-luis-obispo.html">San Luis Obispo <span aria-hidden="true">→</span></a><a href="paso-robles.html">Paso Robles <span aria-hidden="true">→</span></a></div>' +
      '<p class="dish-preview__status" role="status" aria-live="polite" aria-atomic="true"></p>' +
      '<div class="dish-preview__manual" hidden><label for="dish-preview-link">Dish link</label><input id="dish-preview-link" type="url" readonly spellcheck="false"></div></div></div>';
    document.body.append(dialog);

    const find = selector => dialog.querySelector(selector);
    const title = find('#dish-preview-title'), description = find('#dish-preview-description'), category = find('.dish-preview__category');
    const visual = find('.dish-preview__visual'), photo = find('img'), close = find('.dish-preview__close');
    const share = find('.dish-preview__share'), status = find('.dish-preview__status'), manual = find('.dish-preview__manual'), manualInput = find('#dish-preview-link');
    let opener = null, current = null, shareSequence = 0, lockState = null;
    const animations = new Set();
    const stopAnimations = () => { animations.forEach(animation => animation.cancel()); animations.clear(); };
    function enter() {
      if (!allowed() || typeof dialog.animate !== 'function') return;
      try {
        const animation = dialog.animate([{ opacity: 0, transform: 'translateY(18px) scale(.97)' }, { opacity: 1, transform: 'translateY(0) scale(1)' }], { duration: 360, easing: 'cubic-bezier(.22,1,.36,1)' });
        animations.add(animation);
        animation.finished.then(() => animations.delete(animation), () => animations.delete(animation));
      } catch (_) { /* An animation is optional; modal content has its resting CSS state. */ }
    }
    function baseUrl() {
      const currentUrl = new URL(win.location.href);
      return /^https?:$/.test(currentUrl.protocol) ? currentUrl.href : document.querySelector('link[rel="canonical"]')?.href || 'https://antoniaspizza.com/menu.html';
    }
    function open(dish, button) {
      if (dialog.open) return;
      stopAnimations();
      shareSequence++;
      current = dish;
      opener = button;
      title.textContent = dish.name;
      description.textContent = dish.description;
      category.textContent = dish.category || "Antonia's menu";
      visual.hidden = !dish.image;
      dialog.classList.toggle('dish-preview--text', !dish.image);
      if (dish.image) { photo.src = dish.image; photo.alt = dish.name; }
      else { photo.removeAttribute('src'); photo.alt = ''; }
      manual.hidden = true;
      manualInput.value = '';
      status.textContent = '';
      share.disabled = false;
      try { dialog.showModal(); } catch (_) { return; }
      lockState = { html: root.classList.contains('dish-preview-open'), body: document.body.classList.contains('dish-preview-open') };
      root.classList.add('dish-preview-open');
      document.body.classList.add('dish-preview-open');
      close.focus({ preventScroll: true });
      enter();
    }

    dishes.forEach(dish => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'dish-preview-trigger';
      button.textContent = 'Details';
      button.setAttribute('aria-label', 'Details: ' + dish.name);
      button.setAttribute('aria-haspopup', 'dialog');
      button.setAttribute('aria-controls', dialog.id);
      button.addEventListener('click', () => open(dish, button));
      dish.element.append(button);
      dish.button = button;
    });

    close.addEventListener('click', () => dialog.close());
    dialog.addEventListener('cancel', stopAnimations); // Escape retains the native dialog behavior.
    dialog.addEventListener('click', event => {
      if (event.target !== dialog) return;
      const rect = dialog.getBoundingClientRect();
      if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) dialog.close();
    });
    dialog.addEventListener('close', () => {
      stopAnimations();
      shareSequence++;
      if (lockState) {
        if (!lockState.html) root.classList.remove('dish-preview-open');
        if (!lockState.body) document.body.classList.remove('dish-preview-open');
      }
      lockState = null;
      share.disabled = false;
      if (opener?.isConnected) opener.focus({ preventScroll: true });
    });
    share.addEventListener('click', async () => {
      if (!current || share.disabled) return;
      const sequence = ++shareSequence;
      share.disabled = true;
      manual.hidden = true;
      status.textContent = 'Preparing your dish link…';
      try {
        const url = shareUrl(baseUrl(), current);
        const outcome = await shareDish(win.navigator, { title: current.name + " | Antonia's Pizza", text: current.name + " at Antonia's Pizza", url });
        if (!dialog.open || sequence !== shareSequence) return;
        status.textContent = outcome.message;
        if (outcome.method === 'manual') { manual.hidden = false; manualInput.value = outcome.url; manualInput.focus({ preventScroll: true }); manualInput.select(); }
      } finally {
        if (sequence === shareSequence) share.disabled = false;
      }
    });
    function motionChanged() { if (!allowed()) stopAnimations(); }
    document.addEventListener('motionchange', motionChanged);
    document.addEventListener('visibilitychange', motionChanged);
    media?.addEventListener?.('change', motionChanged);
    win.addEventListener('pagehide', () => { if (dialog.open) dialog.close(); else stopAnimations(); });

    const requested = new URL(win.location.href).searchParams.get('dish');
    const matching = requested && dishes.find(dish => dish.key === requested);
    if (matching) open(matching, matching.button);
    return dialog;
  }

  return { images, normalize, slug, fullDescriptions, resolveDish, shareUrl, shareDish, init };
});
