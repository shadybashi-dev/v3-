/* Loads Yelp's official review widget only when the reviews section comes near the screen.
   Without it, each card keeps a plain link to the review on Yelp. */
(() => {
  'use strict';
  const grid = document.querySelector('[data-yelp-reviews]');
  if (!grid) return;
  const load = () => {
    if (document.querySelector('script[src="https://www.yelp.com/embed/widgets.js"]')) return;
    const script = document.createElement('script');
    script.src = 'https://www.yelp.com/embed/widgets.js';
    script.async = true;
    document.body.append(script);
  };
  if (!('IntersectionObserver' in window)) return load();
  const observer = new IntersectionObserver(entries => {
    if (!entries.some(entry => entry.isIntersecting)) return;
    observer.disconnect();
    load();
  }, {rootMargin: '800px 0px'});
  observer.observe(grid);
})();
