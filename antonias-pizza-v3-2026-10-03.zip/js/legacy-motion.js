/* Restored visual behaviors from the supplied September 27 website. */
(() => {
 'use strict';
 const root=document.documentElement,media=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
 const all=(selector)=>Array.from(document.querySelectorAll(selector));
 const enabled=()=>!media.matches&&!root.classList.contains('reduce-motion')&&!root.classList.contains('motion-paused')&&!document.hidden;
 const animations=new Set(),frames=new Set(),resets=new Set();
 function frame(fn){const id=requestAnimationFrame(time=>{frames.delete(id);fn(time);});frames.add(id);return id;}
 function animate(element,keyframes,options){
  if(!enabled()||!element.animate)return;
  const animation=element.animate(keyframes,{duration:700,easing:'cubic-bezier(.22,1,.36,1)',...options});animations.add(animation);
  animation.finished.then(()=>animations.delete(animation),()=>animations.delete(animation));
 }
 const enter=new Map();
 const observer='IntersectionObserver' in window?new IntersectionObserver(entries=>entries.forEach(entry=>{
  if(!entry.isIntersecting)return;observer.unobserve(entry.target);enter.get(entry.target)?.();
 }),{threshold:.2}):null;
 function onEnter(element,fn){if(observer){enter.set(element,fn);observer.observe(element);}else fn();}
 // Text-node splitting keeps outline spans, highlights, links and line breaks intact.
 all('.section-head h2,.wheel-head h2,.loc-hero h1').forEach(heading=>{
  const walker=document.createTreeWalker(heading,NodeFilter.SHOW_TEXT),nodes=[];let node;
  while((node=walker.nextNode()))if(node.nodeValue.trim()&&!node.parentElement.closest('.sr-only'))nodes.push(node);
  const words=[];
  nodes.forEach(node=>{
   const fragment=document.createDocumentFragment();
   node.nodeValue.split(/(\s+)/).forEach(text=>{
    if(!text.trim()){fragment.append(document.createTextNode(text));return;}
    const word=document.createElement('span');word.className='legacy-word';word.textContent=text;fragment.append(word);words.push(word);
   });node.replaceWith(fragment);
  });
  onEnter(heading,()=>words.forEach((word,index)=>animate(word,[{opacity:0,translate:'0 22px',rotate:'3deg'},{opacity:1,translate:'0 0',rotate:'0deg'}],{delay:Math.min(index,14)*55,duration:650})));
 });
 all('[data-count]').forEach(element=>{
  const value=Number(element.dataset.count),suffix=element.dataset.suffix||'',decimals=(element.dataset.count.split('.')[1]||'').length;
  if(!Number.isFinite(value))return;
  const finish=()=>{element.textContent=value.toFixed(decimals)+suffix;};resets.add(finish);
  onEnter(element,()=>{
   if(!enabled()){finish();return;}const start=performance.now();
   function step(time){if(!enabled()){finish();return;}const progress=Math.min(1,(time-start)/1400);element.textContent=(value*(1-Math.pow(1-progress,3))).toFixed(decimals)+suffix;if(progress<1)frame(step);}
   frame(step);
  });
 });
 all('.story-media .frame,.ajarski-media .main').forEach(photo=>onEnter(photo.parentElement,()=>animate(photo,[{clipPath:'inset(0 0 100% 0 round 20px)'},{clipPath:'inset(0 0 0 0 round 20px)'}],{duration:1000})));
 const cardSelector='.dish-card,.deal-card,.deal-mini,.craving-card',interactiveSelector=cardSelector+',.btn';
 const bound=new WeakSet(),hovered=new Set();
 resets.add(()=>{hovered.forEach(reset=>reset());hovered.clear();});
 function interactive(element,kind){
  if(bound.has(element))return;bound.add(element);
  if(kind==='card')element.dataset.legacyBase=element.style.transform||'';
  let queued=false,latest=null;
  const reset=()=>{queued=false;latest=null;hovered.delete(reset);element.classList.remove('legacy-tilt');element.style.removeProperty('--legacy-rx');element.style.removeProperty('--legacy-ry');element.style.removeProperty('translate');element.style.removeProperty('--mx');element.style.removeProperty('--my');};
  element.addEventListener('pointermove',event=>{
   if(!enabled()||!fine.matches||event.pointerType!=='mouse')return;latest=event;hovered.add(reset);
   if(queued)return;queued=true;frame(()=>{
    queued=false;if(!enabled()||!fine.matches||!latest){reset();return;}const rect=element.getBoundingClientRect(),x=(latest.clientX-rect.left)/rect.width-.5,y=(latest.clientY-rect.top)/rect.height-.5;
    if(kind==='card'){element.style.setProperty('--legacy-base',element.dataset.legacyBase||'');element.classList.add('legacy-tilt');element.style.setProperty('--legacy-rx',(-y*7)+'deg');element.style.setProperty('--legacy-ry',(x*7)+'deg');element.style.setProperty('--mx',(latest.clientX-rect.left)+'px');element.style.setProperty('--my',(latest.clientY-rect.top)+'px');}
    else element.style.translate=(x*14)+'px '+(y*10)+'px';
   });
  });
  element.addEventListener('pointerleave',()=>{latest=null;reset();});
 }
 function bind(container){
  if(container.matches?.(interactiveSelector))interactive(container,container.matches('.btn')?'button':'card');
  container.querySelectorAll?.(interactiveSelector).forEach(element=>interactive(element,element.matches('.btn')?'button':'card'));
 }
 bind(document);
 if('MutationObserver' in window)new MutationObserver(records=>records.forEach(record=>record.addedNodes.forEach(node=>{if(node.nodeType===1)bind(node);}))).observe(document.body,{childList:true,subtree:true});
 // Hero motion and marquee velocity are updated only following scroll/pointer input.
 const hero=document.querySelector('.hero-photo,.loc-hero .hero-photo'),tracks=all('.marquee-track');let scrollFrame=false,lastY=scrollY;
 const resetScroll=()=>{hero?.style.removeProperty('translate');tracks.forEach(track=>{track.style.removeProperty('--mq-skew');track.getAnimations?.().forEach(animation=>{animation.playbackRate=1;});});};resets.add(resetScroll);
 addEventListener('scroll',()=>{
  if(!enabled()||scrollFrame)return;scrollFrame=true;
  frame(()=>{
   scrollFrame=false;if(!enabled())return;const velocity=scrollY-lastY;lastY=scrollY;
   if(hero&&fine.matches){const rect=hero.getBoundingClientRect();if(rect.bottom>0&&rect.top<innerHeight)hero.style.translate='0 '+Math.min(35,scrollY*.045)+'px';}
   tracks.forEach(track=>{const rect=track.getBoundingClientRect();if(rect.bottom<0||rect.top>innerHeight)return;track.style.setProperty('--mq-skew',Math.max(-8,Math.min(8,-velocity*.15))+'deg');track.getAnimations?.().forEach(animation=>{animation.playbackRate=(velocity<0?-1:1)*(1+Math.min(Math.abs(velocity)/35,2));});});
   clearTimeout(scrollTimer);scrollTimer=setTimeout(resetScroll,180);
  });
 },{passive:true});let scrollTimer=0;
 // The old pointer ring is decorative; the native pointer remains available.
 const pointer=document.createElement('div');pointer.className='legacy-pointer';pointer.setAttribute('aria-hidden','true');pointer.hidden=true;document.body.append(pointer);
 addEventListener('pointermove',event=>{if(!enabled()||!fine.matches||event.pointerType!=='mouse'){pointer.hidden=true;return;}pointer.hidden=false;pointer.style.translate=event.clientX+'px '+event.clientY+'px';pointer.classList.toggle('over-control',!!event.target.closest('a,button'));},{passive:true});
 document.addEventListener('pointerleave',()=>{pointer.hidden=true;});resets.add(()=>{pointer.hidden=true;});
 function sync(){if(enabled())return;animations.forEach(animation=>animation.cancel());animations.clear();frames.forEach(id=>cancelAnimationFrame(id));frames.clear();scrollFrame=false;lastY=scrollY;clearTimeout(scrollTimer);resets.forEach(reset=>reset());}
 document.addEventListener('motionchange',sync);document.addEventListener('visibilitychange',sync);media.addEventListener('change',sync);fine.addEventListener('change',()=>{resets.forEach(reset=>reset());});
})();
