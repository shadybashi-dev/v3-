(function (root) {
  'use strict';
  function getHours(date, branch = 'slo') {
    const parts = Object.fromEntries(new Intl.DateTimeFormat('en-US', {timeZone:'America/Los_Angeles', weekday:'short', hour:'2-digit', minute:'2-digit', hourCycle:'h23'}).formatToParts(date).map(x => [x.type,x.value]));
    const day = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].indexOf(parts.weekday);
    const minutes = Number(parts.hour)*60 + Number(parts.minute);
    const closes = branch === 'paso' ? [1440,1440,1440,1440,1440,1560,1560] : [1440,1440,1440,1440,1560,1560,1560];
    const previousClose = closes[(day+6)%7];
    const tail = previousClose > 1440 && minutes < previousClose-1440;
    const open = tail || (minutes >= 660 && minutes < closes[day]);
    const until = tail ? previousClose : closes[day];
    return {open, until, late:open && (minutes>=1320 || minutes<180), label:open ? 'Open now · till '+(until===1560?'2 AM':'midnight') : 'Closed · opens 11 AM'};
  }
  if(typeof module === 'object' && module.exports) module.exports = getHours;
  else root.AntoniaHours = getHours;
})(typeof globalThis !== 'undefined' ? globalThis : this);
