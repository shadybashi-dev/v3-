/* A visitor chooses their restaurant explicitly; no location tracking. */
(() => {
 'use strict';
 const branches={
  slo:{name:'San Luis Obispo',short:'SLO',street:'891 Higuera St',address:'891 Higuera St, San Luis Obispo, CA 93401',phone:'(805) 439-2383',tel:'+18054392383',page:'san-luis-obispo.html',image:'assets/img/original-12c6b1cca62f.webp'},
  paso:{name:'Paso Robles',short:'Paso',street:'729 12th St',address:'729 12th St, Paso Robles, CA 93446',phone:'(805) 238-1851',tel:'+18052381851',page:'paso-robles.html',image:'assets/img/original-8e289d677838.webp'}
 };
 const original=document.querySelector('.header-cta .hours-link,.header-cta [data-open-pill]');if(!original)return;
 const dialog=document.createElement('dialog');if(typeof dialog.showModal!=='function')return;
 const root=document.documentElement,media=matchMedia('(prefers-reduced-motion: reduce)'),key='antonias-location-v1';let selected=null,entry=null;
 const valid=id=>id==='slo'||id==='paso';
 try{const saved=localStorage.getItem(key);if(valid(saved))selected=saved;}catch{}
 const trigger=document.createElement('button');trigger.type='button';trigger.className=original.className+' location-choice-trigger';
 const livePill=original.hasAttribute('data-open-pill');
 if(livePill){trigger.setAttribute('data-open-pill','');trigger.dataset.openSchedule=original.dataset.openSchedule;while(original.firstChild)trigger.append(original.firstChild);}
 else trigger.textContent='Choose your spot';
 trigger.setAttribute('aria-haspopup','dialog');trigger.setAttribute('aria-controls','location-choice');trigger.setAttribute('aria-label','Choose your Antonia’s restaurant and view hours');original.replaceWith(trigger);
 dialog.id='location-choice';dialog.className='location-choice';dialog.setAttribute('aria-labelledby','location-choice-title');
 const close=document.createElement('button');close.type='button';close.className='location-choice-close';close.textContent='×';close.setAttribute('aria-label','Close restaurant chooser');
 const heading=document.createElement('h2');heading.id='location-choice-title';heading.textContent='Your pizza. Your spot.';
 const intro=document.createElement('p');intro.className='location-choice-intro';intro.textContent='Two downtown kitchens. Choose the Antonia’s for your next visit.';
 const grid=document.createElement('div');grid.className='location-choice-grid';const controls=[];
 const status=document.createElement('p');status.className='location-choice-status';status.setAttribute('role','status');status.setAttribute('aria-live','polite');
 Object.entries(branches).forEach(([id,branch])=>{
  const card=document.createElement('article'),image=document.createElement('img'),body=document.createElement('div'),title=document.createElement('h3'),address=document.createElement('address'),hours=document.createElement('p'),choose=document.createElement('button'),links=document.createElement('div');
  card.className='location-choice-card';image.src=branch.image;image.alt='Antonia’s Pizza in '+branch.name;image.width=480;image.height=260;image.loading='lazy';image.decoding='async';
  body.className='location-choice-body';title.textContent=branch.name;address.textContent=branch.address;hours.className='location-choice-hours';
  choose.type='button';choose.className='location-choice-select';choose.textContent='Make '+branch.short+' my spot';choose.setAttribute('aria-pressed',String(selected===id));
  choose.addEventListener('click',()=>{
   selected=id;let persisted=true;try{localStorage.setItem(key,id);}catch{persisted=false;}sync();
   status.textContent=branch.name+' selected. '+(persisted?'Saved on this device.':'Selected for this visit.');
  });
  links.className='location-choice-links';
  [['View location',branch.page],['Directions','https://www.google.com/maps/search/?api=1&query='+encodeURIComponent(branch.address)],['Call '+branch.phone,'tel:'+branch.tel]].forEach(([text,url])=>{const link=document.createElement('a');link.textContent=text;link.href=url;if(url.startsWith('https:')){link.target='_blank';link.rel='noopener';}links.append(link);});
  body.append(title,address,hours,choose,links);card.append(image,body);grid.append(card);controls.push({id,card,hours,choose});
 });
 const checkout=document.createElement('p');checkout.className='location-choice-note';checkout.textContent='For online orders, choose this same restaurant in the ordering menu before checkout. Hours shown are Pacific Time; holiday hours may vary.';
 dialog.append(close,heading,intro,grid,status,checkout);document.body.append(dialog);
 let announced;
 function sync(){
  if(!livePill)trigger.textContent=selected?branches[selected].short+' · Hours':'Choose your spot';
  controls.forEach(({id,card,hours,choose})=>{choose.setAttribute('aria-pressed',String(selected===id));card.classList.toggle('is-chosen',selected===id);hours.textContent=typeof window.AntoniaHours==='function'?window.AntoniaHours(new Date(),id).label:'View location for opening hours';});
  if(announced!==selected){announced=selected;document.dispatchEvent(new CustomEvent('antonia:location-change',{detail:selected?{id:selected,...branches[selected]}:null}));}
 }
 function stop(){if(media.matches||root.classList.contains('reduce-motion')||root.classList.contains('motion-paused')||document.hidden){entry?.cancel();entry=null;}}
 trigger.addEventListener('click',()=>{
  sync();status.textContent='';dialog.showModal();document.body.classList.add('location-dialog-open');root.classList.add('location-dialog-open');close.focus();
  if(!media.matches&&!root.classList.contains('reduce-motion')&&!root.classList.contains('motion-paused')&&!document.hidden&&dialog.animate){const animation=dialog.animate([{opacity:0,translate:'0 16px',scale:'.97'},{opacity:1,translate:'0 0',scale:'1'}],{duration:350,easing:'cubic-bezier(.22,1,.36,1)'});entry=animation;const done=()=>{if(entry===animation)entry=null;};animation.finished.then(done,done);}
 });
 close.addEventListener('click',()=>dialog.close());
 dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const rect=dialog.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)dialog.close();});
 dialog.addEventListener('close',()=>{entry?.cancel();entry=null;document.body.classList.remove('location-dialog-open');root.classList.remove('location-dialog-open');trigger.focus({preventScroll:true});});
 document.addEventListener('motionchange',stop);document.addEventListener('visibilitychange',stop);media.addEventListener('change',stop);
 addEventListener('pagehide',()=>{if(dialog.open)dialog.close();});addEventListener('pageshow',()=>{try{const saved=localStorage.getItem(key);selected=valid(saved)?saved:null;}catch{}sync();});
 addEventListener('focus',()=>{if(dialog.open)sync();});setInterval(()=>{if(dialog.open)sync();},60000);sync();
})();
