/* Apply the saved preference before the first paint and page transition. */
(() => {
 // Switch to the scripted layout before the first paint so the page does not jump when main.js runs.
 document.documentElement.classList.add('js');
 // main.js marks the body as loaded; if it never ran, fall back to the no-script layout so nothing stays hidden.
 addEventListener('load',()=>{if(!document.body.classList.contains('loaded'))document.documentElement.classList.remove('js');});
 const policy=document.createElement('style');policy.id='motion-nav-policy';document.head.append(policy);
 function refresh(){
  let paused=document.documentElement.classList.contains('motion-paused');try{paused=sessionStorage.getItem('antonias-motion-paused')==='true';}catch{}
  const reduced=paused||matchMedia('(prefers-reduced-motion: reduce)').matches;
  document.documentElement.classList.toggle('reduce-motion',reduced);document.documentElement.classList.toggle('motion-paused',reduced);
  policy.textContent=reduced?'@view-transition {navigation: none;}':'';return reduced;
 }
 refresh();
 const skip=event=>{if(refresh())event.viewTransition?.skipTransition();};
 addEventListener('pageswap',skip);addEventListener('pagereveal',skip);
})();
