/* Distinctive food moments, without blocking ordering or page navigation. */
(() => {
 'use strict';
 const root=document.documentElement,media=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
 const allowed=()=>!media.matches&&!root.classList.contains('reduce-motion')&&!root.classList.contains('motion-paused')&&!document.hidden;
 const active=new Set(),cleanups=new Set();let frame=0;
 function animate(element,frames,options={}){
  if(!allowed()||!element?.animate)return null;
  const animation=element.animate(frames,{duration:550,easing:'cubic-bezier(.22,1,.36,1)',...options});active.add(animation);
  animation.finished.then(()=>active.delete(animation),()=>active.delete(animation));return animation;
 }
 const hero=document.querySelector('.hero-photo');
 if(hero){
  const front=hero.querySelector('.ph-main'),back=hero.querySelector('.ph-back'),badge=hero.querySelector('.sticker');
  const aura=document.createElement('div');aura.className='oven-aura';aura.setAttribute('aria-hidden','true');hero.prepend(aura);
  const reset=()=>{[front,back,badge].forEach(element=>{element?.style.removeProperty('--depth-x');element?.style.removeProperty('--depth-y');});};cleanups.add(reset);
  let position=null;
  hero.addEventListener('pointermove',event=>{
   if(!allowed()||!fine.matches||event.pointerType!=='mouse')return;position={x:event.clientX,y:event.clientY};
   if(frame)return;frame=requestAnimationFrame(()=>{
    frame=0;if(!allowed()||!fine.matches||!position){reset();return;}const rect=hero.getBoundingClientRect(),x=(position.x-rect.left)/rect.width-.5,y=(position.y-rect.top)/rect.height-.5;
    [[front,18],[back,-12],[badge,25]].forEach(([element,depth])=>{element?.style.setProperty('--depth-x',x*depth+'px');element?.style.setProperty('--depth-y',y*depth+'px');});
   });
  });hero.addEventListener('pointerleave',()=>{position=null;reset();});
 }
 // A full-photo view grows from the image the visitor selects.
 const figures=Array.from(document.querySelectorAll('.gallery-track figure')).filter(figure=>figure.querySelector('img'));
 if(figures.length){
  const dialog=document.createElement('dialog');dialog.className='food-lightbox';dialog.setAttribute('aria-labelledby','food-lightbox-title');
  const close=document.createElement('button');close.type='button';close.className='lightbox-close';close.textContent='Close ×';
  const image=document.createElement('img'),caption=document.createElement('p');caption.id='food-lightbox-title';dialog.append(close,image,caption);document.body.append(dialog);
  if(typeof dialog.showModal==='function'){
   let trigger=null,closing=false,current=0,imageAnimation=null;
   const photoButtons=[];
   function animatePhoto(frames,duration){imageAnimation?.cancel();imageAnimation=animate(image,frames,{duration});return imageAnimation;}
   function setPhoto(index,animateChange=true){
    current=(index+figures.length)%figures.length;const figure=figures[current],source=figure.querySelector('img');
    image.src=source.getAttribute('data-full-src')||source.currentSrc||source.src;image.alt=source.alt;caption.textContent=figure.querySelector('figcaption')?.textContent||source.alt;
    if(animateChange)animatePhoto([{opacity:0,scale:'.86',rotate:'-2deg'},{opacity:1,scale:'1',rotate:'0deg'}],450);
   }
   const previous=document.createElement('button'),next=document.createElement('button');
   previous.type=next.type='button';previous.className='lightbox-previous';next.className='lightbox-next';previous.textContent='←';next.textContent='→';previous.setAttribute('aria-label','Previous photo');next.setAttribute('aria-label','Next photo');dialog.append(previous,next);
   previous.addEventListener('click',()=>{if(!closing)setPhoto(current-1);});next.addEventListener('click',()=>{if(!closing)setPhoto(current+1);});
   dialog.addEventListener('keydown',event=>{if(closing)return;if(event.key==='ArrowLeft'){event.preventDefault();setPhoto(current-1);}if(event.key==='ArrowRight'){event.preventDefault();setPhoto(current+1);}});
   function closePhoto(immediate=false){
    if(!dialog.open||closing)return;closing=true;
    const done=()=>{dialog.close();closing=false;document.body.classList.remove('photo-open');trigger?.focus({preventScroll:true});};
    const animation=immediate?null:animatePhoto([{opacity:1,scale:'1'},{opacity:0,scale:'.9'}],180);
    if(animation)animation.finished.then(done,done);else done();
   }
   close.addEventListener('click',()=>closePhoto());dialog.addEventListener('cancel',event=>{event.preventDefault();closePhoto();});
   dialog.addEventListener('click',event=>{if(event.target===dialog)closePhoto();});
   dialog.addEventListener('close',()=>document.body.classList.remove('photo-open'));
   figures.forEach((figure,index)=>{
    const source=figure.querySelector('img');if(!source)return;
    const button=document.createElement('button');button.type='button';button.className='gallery-photo-button';button.setAttribute('aria-label','View photo: '+source.alt);source.before(button);button.append(source);
    photoButtons.push(button);
    button.addEventListener('click',()=>{
     trigger=button;setPhoto(index,false);
     dialog.showModal();document.body.classList.add('photo-open');close.focus();
     animatePhoto([{opacity:0,scale:'.8',rotate:'-3deg'},{opacity:1,scale:'1',rotate:'0deg'}],520);
    });
   });
  }
 }
 // Celebration occurs only after a completed deliberate spin, never on page load.
 document.addEventListener('antonia:spin-complete',event=>{
  if(!allowed())return;const result=event.detail?.result;if(!result)return;
  const card=result.firstElementChild;animate(card,[{opacity:0,scale:'.85',translate:'0 18px'},{opacity:1,scale:'1.035',translate:'0 -2px',offset:.75},{opacity:1,scale:'1',translate:'0 0'}],{duration:650});
  const rect=result.getBoundingClientRect(),layer=document.createElement('div');layer.className='food-celebration';layer.setAttribute('aria-hidden','true');document.body.append(layer);
  const remove=()=>{layer.remove();cleanups.delete(remove);};cleanups.add(remove);
  const x=Math.max(40,Math.min(innerWidth-40,rect.left+rect.width/2)),y=Math.max(40,Math.min(innerHeight-40,rect.top+24));let last=null;
  for(let i=0;i<16;i++){
   const spark=document.createElement('i');spark.style.left=x+'px';spark.style.top=y+'px';spark.style.background=['#e6b83b','#e2492f','#0e3a52'][i%3];layer.append(spark);
   const angle=Math.PI*2*i/16,distance=65+(i%4)*22;
   last=animate(spark,[{opacity:1,translate:'0 0',rotate:'0deg'},{opacity:0,translate:Math.cos(angle)*distance+'px '+(Math.sin(angle)*distance+50)+'px',rotate:(i%2?150:-150)+'deg'}],{duration:900});
  }
  if(last)last.finished.then(remove,remove);else remove();
 });
 function stop(){if(allowed())return;active.forEach(animation=>animation.cancel());active.clear();if(frame){cancelAnimationFrame(frame);frame=0;}cleanups.forEach(cleanup=>cleanup());}
 document.addEventListener('motionchange',stop);document.addEventListener('visibilitychange',stop);media.addEventListener('change',stop);fine.addEventListener('change',()=>cleanups.forEach(cleanup=>cleanup()));
})();
