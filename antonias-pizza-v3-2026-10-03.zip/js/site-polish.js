(() => {
  'use strict';
  const current = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(link => {
    const destination = new URL(link.href);
    if (!destination.hash && destination.pathname.split('/').pop() === current) link.setAttribute('aria-current', 'page');
  });
  const button = document.createElement('button');
  button.type = 'button';
  button.className = 'back-to-top';
  button.textContent = '↑';
  button.setAttribute('aria-label', 'Back to top');
  button.hidden = true;
  document.body.append(button);
  let queued = false;
  function update() {button.hidden = window.scrollY < 800; queued = false;}
  window.addEventListener('scroll', () => {if (!queued) {queued = true; requestAnimationFrame(update);}}, {passive: true});
  button.addEventListener('click', () => {
    const target = document.querySelector('.skip-link');
    target?.focus({preventScroll: true});
    window.scrollTo({top: 0, behavior: document.documentElement.classList.contains('reduce-motion') ? 'instant' : 'smooth'});
  });
  update();

  // Section links. "/" and "index.html" are the same page, so "index.html#deals" scrolls
  // in place instead of reloading. A page opened with a #section lands on it once late
  // layout (revealed sections, fonts) has settled, unless the visitor has already scrolled.
  const page = url => url.pathname.split('/').pop() || 'index.html';
  const sectionFor = hash => {
    try {return hash.length > 1 ? document.getElementById(decodeURIComponent(hash.slice(1))) : null;} catch {return null;}
  };
  const reduced = () => document.documentElement.classList.contains('reduce-motion');
  function land(target, smooth) {
    target.scrollIntoView({behavior: smooth && !reduced() ? 'smooth' : 'instant', block: 'start'});
    if (!target.matches('a[href],button,input,select,textarea,[tabindex]')) target.setAttribute('tabindex', '-1');
    target.focus({preventScroll: true});
  }
  document.addEventListener('click', event => {
    const link = event.target.closest?.('a[href*="#"]');
    if (!link || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || link.target === '_blank') return;
    const url = new URL(link.href);
    if (url.origin !== location.origin || page(url) !== current || url.pathname === location.pathname) return;
    const target = sectionFor(url.hash);
    if (!target) return;
    event.preventDefault();
    history.pushState(null, '', url.hash);
    land(target, true);
  });
  const initial = sectionFor(location.hash);
  if (initial) {
    let moved = false;
    const stop = () => {moved = true;};
    ['wheel', 'touchstart', 'keydown'].forEach(type => window.addEventListener(type, stop, {once: true, passive: true}));
    const settle = () => {if (!moved) initial.scrollIntoView({behavior: 'instant', block: 'start'});};
    if (document.readyState === 'complete') requestAnimationFrame(settle);
    else window.addEventListener('load', () => requestAnimationFrame(settle), {once: true});
    document.fonts?.ready.then(() => requestAnimationFrame(settle));
  }
})();
