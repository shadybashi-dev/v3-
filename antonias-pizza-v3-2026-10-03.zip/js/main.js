/* Antonia's Pizza — progressive, dependency-free interactions. */
(() => {
  'use strict';
  const $ = (s,c=document)=>c.querySelector(s);
  const $$ = (s,c=document)=>Array.from(c.querySelectorAll(s));
  const root=document.documentElement;
  const mq=matchMedia('(prefers-reduced-motion: reduce)');
  let userPaused=false;
  try{userPaused=sessionStorage.getItem('antonias-motion-paused')==='true';}catch{}
  const reduced=()=>mq.matches||userPaused;
  function syncMotion(){
    root.classList.toggle('reduce-motion',reduced());
    root.classList.toggle('motion-paused',reduced());
    const policy=document.getElementById('motion-nav-policy');if(policy)policy.textContent=reduced()?'@view-transition {navigation: none;}':'';
    try{sessionStorage.setItem('antonias-motion-paused',String(userPaused));}catch{}
    document.dispatchEvent(new Event('motionchange'));
    const b=$('[data-motion-toggle]');
    if(b){b.disabled=mq.matches;b.setAttribute('aria-pressed',String(reduced()));b.textContent=mq.matches?'Reduced motion enabled':reduced()?'Motion paused':'Pause motion';}
  }
  $('[data-motion-toggle]')?.addEventListener('click',()=>{userPaused=!reduced();syncMotion();});
  mq.addEventListener('change',syncMotion);syncMotion();
  addEventListener('pageshow',()=>{try{userPaused=sessionStorage.getItem('antonias-motion-paused')==='true';}catch{}syncMotion();});
  document.body.classList.add('loaded');
  $('.preloader')?.remove();
  $$('.cursor-dot,.cursor-ring').forEach(x=>x.remove());

  const header=$('.site-header'),nav=$('.nav-links'),toggle=$('.nav-toggle');
  const mobile=matchMedia('(max-width: 960px)');
  function setNav(open,restore=false){
    open=!!open&&mobile.matches;
    document.body.classList.toggle('nav-open',open);
    toggle?.setAttribute('aria-expanded',String(open));
    toggle?.setAttribute('aria-label',open?'Close menu':'Open menu');
    if(nav){nav.inert=mobile.matches&&!open;nav.setAttribute('aria-hidden',String(mobile.matches&&!open));}
    if(open)$('a',nav)?.focus();else if(restore)toggle?.focus();
  }
  toggle?.addEventListener('click',()=>setNav(!document.body.classList.contains('nav-open')));
  $$('.nav-links a').forEach(a=>a.addEventListener('click',()=>setNav(false,true)));
  mobile.addEventListener('change',()=>setNav(false));
  addEventListener('keydown',e=>{
    if(!document.body.classList.contains('nav-open'))return;
    if(e.key==='Escape'){e.preventDefault();setNav(false,true);}
    if(e.key==='Tab'){
      const links=$$('a',nav),first=links[0];
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();toggle.focus();}
      else if(!e.shiftKey&&document.activeElement===links[links.length-1]){e.preventDefault();toggle.focus();}
      else if(!e.shiftKey&&document.activeElement===toggle){e.preventDefault();first.focus();}
      else if(e.shiftKey&&document.activeElement===toggle){e.preventDefault();links[links.length-1]?.focus();}
    }
  });
  setNav(false);
  function headerSize(){if(header)root.style.setProperty('--header-h',Math.ceil(header.getBoundingClientRect().height)+'px');}
  if(header&&window.ResizeObserver)new ResizeObserver(headerSize).observe(header);
  headerSize();
  // A chosen restaurant turns the sticky bar's second action into a direct call.
  document.addEventListener('antonia:location-change',event=>{const alt=$('[data-sticky-alt]'),branch=event.detail;if(!alt)return;if(!alt.dataset.href){alt.dataset.href=alt.getAttribute('href');alt.dataset.label=alt.textContent;alt.dataset.hidden=String(alt.hidden);}
    if(branch){alt.href='tel:'+branch.tel;alt.textContent='Call '+branch.short;alt.setAttribute('aria-label','Call Antonia’s '+branch.name);alt.hidden=false;}else{alt.href=alt.dataset.href;alt.textContent=alt.dataset.label;alt.removeAttribute('aria-label');alt.hidden=alt.dataset.hidden==='true';}});
  let frame=0;
  addEventListener('scroll',()=>{
    if(frame)return;
    frame=requestAnimationFrame(()=>{frame=0;header?.classList.toggle('scrolled',scrollY>40);const sticky=$('.sticky-order');
      if(sticky){const show=scrollY>innerHeight*.9;sticky.classList.toggle('show',show);root.classList.toggle('sticky-order-on',show);sticky.inert=!show;sticky.setAttribute('aria-hidden',String(!show));$$('a',sticky).forEach(link=>link.tabIndex=show?0:-1);}
    });
  },{passive:true});

  // Content stays visible if JavaScript, observers or animations are unavailable.
  const revealTargets=$$('.reveal,.stagger');
  if('IntersectionObserver' in window){
    const io=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target);}}),{threshold:.08});
    revealTargets.forEach(el=>io.observe(el));
  }else revealTargets.forEach(el=>el.classList.add('in'));
  $$('.story-media .frame,.ajarski-media .main').forEach(x=>x.classList.add('clip-in'));
  $$('[data-count]').forEach(el=>el.textContent=el.dataset.count+(el.dataset.suffix||''));

  $$('.faq-item').forEach((item,i)=>{
    const button=$('button',item),panel=$('.faq-a',item);if(!button||!panel)return;
    panel.id='faq-answer-'+i;button.id='faq-question-'+i;
    button.setAttribute('aria-controls',panel.id);button.setAttribute('aria-expanded','false');
    panel.setAttribute('aria-labelledby',button.id);panel.hidden=true;
    button.addEventListener('click',()=>{const open=button.getAttribute('aria-expanded')!=='true';button.setAttribute('aria-expanded',String(open));panel.hidden=!open;item.classList.toggle('open',open);panel.style.maxHeight=open?'none':'';});
  });
  const tabs=$$('.loc-tabs button');
  function selectTab(index,focus=false){tabs.forEach((tab,i)=>{const selected=i===index,panel=document.getElementById(tab.dataset.target);tab.classList.toggle('active',selected);tab.setAttribute('aria-selected',String(selected));tab.tabIndex=selected?0:-1;tab.id='tab-'+tab.dataset.target;tab.setAttribute('aria-controls',tab.dataset.target);if(panel){panel.hidden=!selected;panel.classList.toggle('active',selected);panel.setAttribute('aria-labelledby',tab.id);panel.tabIndex=0;}if(selected&&focus)tab.focus();});}
  tabs.forEach((tab,i)=>{tab.addEventListener('click',()=>selectTab(i));tab.addEventListener('keydown',e=>{let next;if(e.key==='ArrowRight')next=(i+1)%tabs.length;if(e.key==='ArrowLeft')next=(i+tabs.length-1)%tabs.length;if(e.key==='Home')next=0;if(e.key==='End')next=tabs.length-1;if(next!==undefined){e.preventDefault();selectTab(next,true);}});});
  if(tabs.length)selectTab(0);

  function updateHours(){
    if(!window.AntoniaHours)return;
    const date=new Date();
    $$('[data-open-pill]').forEach(pill=>{const state=AntoniaHours(date,pill.dataset.openSchedule||'slo');pill.classList.toggle('closed',!state.open);const label=$('.label',pill);if(label)label.textContent=state.label;});
    const branch=document.body.dataset.location;
    const state=AntoniaHours(date,branch||'slo');const other=AntoniaHours(date,'paso');
    const late=branch?state.late:(state.late||other.late);
    root.classList.toggle('late',late);
    const bar=$('[data-late-bar]'),text=$('[data-late-text]');
    if(bar)bar.hidden=!late;
    if(text)text.textContent=branch?'Late night at Antonia’s — '+state.label.toLowerCase():'Late-night pizza · check your location’s hours';
  }
  updateHours();setInterval(updateHours,60000);
  addEventListener('focus',updateHours);

  // Decorative marquees duplicate once; the gallery is a manual, keyboard-scrollable strip.
  $$('.marquee-track').forEach(track=>Array.from(track.children).forEach(child=>{const copy=child.cloneNode(true);copy.setAttribute('aria-hidden','true');track.append(copy);}));
  const gallery=$('.gallery-track');if(gallery){gallery.tabIndex=0;gallery.setAttribute('role','region');gallery.setAttribute('aria-label','Food gallery. Scroll to explore.');}

  const rail=$('.menu-rail');
  if(rail){const chips=$$('.menu-chip',rail),targets=chips.map(chip=>({chip,section:document.getElementById(chip.hash.slice(1))})).filter(x=>x.section);
    const mark=chip=>{chips.forEach(x=>x===chip?x.setAttribute('aria-current','true'):x.removeAttribute('aria-current'));};
    chips.forEach(chip=>chip.addEventListener('click',()=>mark(chip)));
    if(targets.length){mark(targets[0].chip);if('IntersectionObserver' in window){const seen=new Map(),io=new IntersectionObserver(entries=>{entries.forEach(e=>seen.set(e.target,e.isIntersecting));const active=targets.find(x=>seen.get(x.section));if(active)mark(active.chip);},{rootMargin:'-25% 0px -60% 0px'});targets.forEach(x=>io.observe(x.section));}}
  }

  // Food showcase can rotate automatically; manual selection always takes control.
  $$('[data-wheel]').forEach(wheel=>{
    const rotor=$('.pie-rotor',wheel);if(!rotor)return;
    const slices=$$('.slice',rotor),n=slices.length;if(!n)return;
    const mod=(v)=>((v%n)+n)%n;let rotation=0,current=0,startX=0,startRotation=0,dragging=false,moved=false;
    function render(animate=true){
      rotor.style.transition=animate&&!reduced()?'transform .65s cubic-bezier(.22,1,.36,1)':'none';
      rotor.style.transform='rotate('+rotation+'deg)';rotor.style.setProperty('--wheel-rotation',rotation+'deg');
      current=mod(Math.round(-rotation/(360/n)));
      slices.forEach((s,i)=>{s.classList.toggle('active',i===current);s.setAttribute('aria-selected',String(i===current));s.tabIndex=i===current?0:-1;});
      const selected=slices[current];$$('[data-dish-name],[data-side-name]').forEach(el=>el.textContent=selected.dataset.name);$$('[data-craving-out]').forEach(el=>el.textContent=selected.dataset.craving);
    }
    function go(index,focus=false){index=mod(index);let diff=(-index*360/n-rotation+180)%360;if(diff<0)diff+=360;rotation+=diff-180;render();if(focus)slices[index].focus({preventScroll:true});}
    slices.forEach((s,i)=>{s.addEventListener('click',()=>{if(!moved)go(i);});s.addEventListener('keydown',e=>{const keys=['ArrowRight','ArrowDown','ArrowLeft','ArrowUp','Home','End','Enter',' '];if(!keys.includes(e.key))return;e.preventDefault();const j=e.key==='Home'?0:e.key==='End'?n-1:/Right|Down/.test(e.key)?current+1:/Left|Up/.test(e.key)?current-1:i;go(j,true);});});
    rotor.addEventListener('pointerdown',e=>{if(e.button!==0)return;dragging=true;moved=false;startX=e.clientX;startRotation=rotation;});
    rotor.addEventListener('pointermove',e=>{if(!dragging)return;if(Math.abs(e.clientX-startX)>8){moved=true;rotor.setPointerCapture(e.pointerId);}if(moved){rotation=startRotation+(e.clientX-startX)*.65;render(false);}});
    const release=()=>{if(!dragging)return;dragging=false;if(moved){rotation=Math.round(rotation/(360/n))*360/n;render();setTimeout(()=>moved=false,0);}};
    rotor.addEventListener('pointerup',release);rotor.addEventListener('pointercancel',release);rotor.addEventListener('lostpointercapture',release);
    addEventListener('pointerup',release);addEventListener('pointercancel',release);addEventListener('blur',release);
    $('[data-wheel-next]',wheel.closest('section'))?.addEventListener('click',()=>go(current+1));
    $('[data-wheel-prev]',wheel.closest('section'))?.addEventListener('click',()=>go(current-1));
    render(false);
    const section=wheel.closest('section');
    const autoButton=document.createElement('button');autoButton.type='button';autoButton.className='wheel-auto-toggle';autoButton.textContent='Pause wheel';autoButton.setAttribute('aria-label','Pause automatic dish rotation');
    (section?.querySelector('.wheel-head')||wheel.parentElement)?.append(autoButton);
    let auto=true,visible=false,hovered=false,autoTimer=0;
    function syncAuto(){
      clearInterval(autoTimer);autoTimer=0;
      autoButton.textContent=auto?'Pause wheel':'Play wheel';autoButton.setAttribute('aria-label',auto?'Pause automatic dish rotation':'Play automatic dish rotation');autoButton.setAttribute('aria-pressed',String(auto));
      autoButton.disabled=reduced();
      if(auto&&visible&&!hovered&&!dragging&&!reduced()&&!document.hidden&&!section?.contains(document.activeElement))autoTimer=setInterval(()=>go(current+1),4500);
    }
    autoButton.addEventListener('click',()=>{auto=!auto;syncAuto();});
    section?.addEventListener('pointerdown',event=>{if(event.target===autoButton)return;auto=false;syncAuto();});
    section?.addEventListener('keydown',event=>{if(event.target===autoButton)return;if(['ArrowRight','ArrowLeft','ArrowUp','ArrowDown','Enter',' '].includes(event.key)){auto=false;syncAuto();}});
    wheel.addEventListener('pointerenter',event=>{if(event.pointerType==='mouse'){hovered=true;syncAuto();}});
    wheel.addEventListener('pointerleave',()=>{hovered=false;syncAuto();});
    section?.addEventListener('focusin',syncAuto);section?.addEventListener('focusout',()=>setTimeout(syncAuto,0));
    document.addEventListener('motionchange',syncAuto);document.addEventListener('visibilitychange',syncAuto);
    if('IntersectionObserver' in window)new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;syncAuto();},{threshold:.3}).observe(wheel);
    syncAuto();
  });
  $$('[data-spin-wheel]').forEach(wheel=>{
    const disc=$('.sw-disc',wheel),hub=$('[data-spin-go]',wheel),result=$('[data-spin-result]',wheel.closest('.spin-card'));if(!disc||!hub||!result)return;
    let items;try{items=JSON.parse(wheel.dataset.spinItems);}catch{return;}if(!items.length)return;
    wheel.classList.add('spin-wheel--pies');disc.replaceChildren();disc.setAttribute('aria-hidden','true');
    items.forEach((item,i)=>{const thumb=document.createElement('div');thumb.className='picker-photo';thumb.style.setProperty('--angle',(i*360/items.length+180/items.length)+'deg');const img=document.createElement('img');img.src=item.img;img.alt='';img.loading='lazy';img.width=512;img.height=512;thumb.append(img);disc.append(thumb);});
    const pointer=$('.sw-pointer',wheel);if(pointer)pointer.textContent='▼';
    let busy=false,rotation=0,timer=0,finishSpin=null;
    function spin(){if(busy)return;busy=true;hub.disabled=true;result.textContent='Picking your pizza…';
      const index=Math.floor(Math.random()*items.length),item=items[index];rotation=(Math.floor(rotation/360)-5)*360-(index+.5)*(360/items.length);
      let finished=false;
      const done=()=>{if(finished)return;finished=true;clearTimeout(timer);disc.removeEventListener('transitionend',onEnd);busy=false;hub.disabled=false;wheel.classList.remove('is-spinning');const card=document.createElement('div');card.className='sw-card';const img=document.createElement('img');img.src=item.img;img.alt=item.name;const text=document.createElement('div'),title=document.createElement('div'),note=document.createElement('p');title.className='sw-k';title.textContent=item.name;note.className='sw-n';note.textContent=item.note;text.append(title,note);const a=document.createElement('a');a.href='https://antoniaspizza.toast.site/';a.target='_blank';a.rel='noopener';a.className='btn btn--sm';a.textContent='Order online ↗';card.append(img,text,a);result.replaceChildren(card);document.dispatchEvent(new CustomEvent("antonia:spin-complete",{detail:{result,kind:"pizza"}}));};
      const onEnd=e=>{if(e.target===disc&&e.propertyName==='transform')done();};finishSpin=done;
      disc.style.transition=reduced()?'none':'';disc.style.transform='rotate('+rotation+'deg)';disc.style.setProperty('--picker-rotation',rotation+'deg');
      if(reduced())done();else{wheel.classList.add('is-spinning');disc.addEventListener('transitionend',onEnd);timer=setTimeout(done,5100);}
    }
    hub.setAttribute('aria-label','Spin to pick your pizza');hub.addEventListener('click',spin);
    mq.addEventListener('change',()=>{if(reduced()&&busy)finishSpin?.();});
    document.addEventListener('motionchange',()=>{if(reduced()&&busy)finishSpin?.();});
  });
  // All three approved offers have two segments each and equal odds.
  $$('[data-offer-wheel]').forEach(wheel=>{
    const api=window.AntoniaOffers,disc=$('.sw-disc',wheel),button=$('[data-offer-go]',wheel),result=$('[data-offer-result]',wheel.closest('.spin-card'));
    if(!api||!disc||!button||!result)return;
    const storageKey='antonias-approved-offer-v1';let busy=false,saved=null,timer=0,finish=null;
    try{saved=api.restore(JSON.parse(localStorage.getItem(storageKey)));}catch{}
    const show=offer=>{
      const prize=api.prizes[offer.index%3];
      const card=document.createElement('div');card.className='offer-ticket';
      const kicker=document.createElement('span');kicker.className='eyebrow';kicker.textContent='Your offer is ready';
      const title=document.createElement('strong');title.className='offer-value';title.textContent=prize.title;
      const date=document.createElement('p');date.textContent='Valid '+new Intl.DateTimeFormat('en-US',{month:'short',day:'numeric',year:'numeric',timeZone:'UTC'}).format(new Date(offer.day+'T12:00:00Z'))+' · Show at the counter';
      const note=document.createElement('p');note.className='offer-keep';note.textContent='Keep this page or a screenshot of your offer.';
      card.append(kicker,title,date,note);result.replaceChildren(card);button.disabled=true;button.innerHTML='<span>SAVED</span>';button.setAttribute('aria-label','Today’s offer is saved');
    };
    const align=offer=>{disc.style.transition='none';disc.style.transform='rotate('+api.rotation(offer.index)+'deg)';disc.style.setProperty('--offer-turn',api.rotation(offer.index)+'deg');};
    if(saved){align(saved);show(saved);}
    button.addEventListener('click',()=>{
      if(busy)return;
      // Re-read before a spin to respect an offer claimed in another tab.
      try{const data=api.restore(JSON.parse(localStorage.getItem(storageKey)));if(data){saved=data;align(saved);show(saved);return;}}catch{}
      saved=api.create(api.randomIndex());
      try{localStorage.setItem(storageKey,JSON.stringify(saved));}catch{}
      busy=true;button.disabled=true;result.textContent='Your treat is on its way…';wheel.classList.add('is-spinning');
      let finished=false;
      const done=()=>{if(finished)return;finished=true;clearTimeout(timer);disc.removeEventListener('transitionend',onEnd);busy=false;wheel.classList.remove('is-spinning');show(saved);document.dispatchEvent(new CustomEvent('antonia:spin-complete',{detail:{result,kind:'offer'}}));};
      const onEnd=e=>{if(e.target===disc&&e.propertyName==='transform')done();};finish=done;
      disc.style.transition=reduced()?'none':'';disc.style.transform='rotate('+api.rotation(saved.index)+'deg)';disc.style.setProperty('--offer-turn',api.rotation(saved.index)+'deg');
      if(reduced())done();else{disc.addEventListener('transitionend',onEnd);timer=setTimeout(done,5100);}
    });
    const refresh=()=>{if(saved&&!api.valid(saved)&&!busy){saved=null;button.disabled=false;button.innerHTML='<span>SPIN</span>';button.setAttribute('aria-label','Spin for $5 off, 10% off or a free giant slice');disc.style.transition='none';disc.style.transform='rotate(0deg)';disc.style.setProperty('--offer-turn','0deg');result.textContent='A new day, a new treat. Take a spin!';}};
    setInterval(refresh,60000);addEventListener('focus',refresh);
    mq.addEventListener('change',()=>{if(reduced()&&busy)finish?.();});
    document.addEventListener('motionchange',()=>{if(reduced()&&busy)finish?.();});
  });
  $$('[data-sizer]').forEach(sizer=>{const input=$('[data-sizer-input]',sizer),pie=$('[data-sizer-pie]',sizer),inches=$('[data-sizer-inches]',sizer),out=$('[data-sizer-out]',sizer),feeds=$('[data-sizer-feeds]',sizer),ratio=$('[data-sizer-ratio]',sizer),next=$('[data-sizer-next]',sizer);if(!input||!pie)return;const sizes=[10,13,16,18,24,28],choices=$$('[data-pizza-size]',sizer);
    // Same serving baseline as the group planner: a 16-inch pizza feeds 3; other sizes scale by area.
    const people=value=>Math.max(1,Math.round(3*(value/16)**2)),times=value=>(value/10)**2;
    function render(){const index=Number(input.value),value=sizes[index]||10,fed=people(value),upsize=sizes[index+1];pie.style.setProperty('--in',value);if(inches)inches.textContent=value+'"';if(feeds)feeds.textContent=fed+(fed===1?' person':' people');if(ratio)ratio.textContent=value===10?'Personal':times(value).toFixed(1)+'×';if(next)next.textContent=upsize?'Size up to '+upsize+'" for '+Math.round(((upsize/value)**2-1)*100)+'% more pizza.':'Our biggest pie. Made for a crowd.';if(out)out.textContent=value+'-inch pizza. Feeds about '+fed+(fed===1?' person.':' people.')+(value===10?'':' '+times(value).toFixed(1)+' times the pizza of a 10-inch.');input.setAttribute('aria-valuetext',value+' inches');choices.forEach(button=>button.setAttribute('aria-pressed',String(Number(button.dataset.pizzaSize)===index)));}input.addEventListener('input',render);choices.forEach(button=>button.addEventListener('click',()=>{input.value=button.dataset.pizzaSize;input.dispatchEvent(new Event('input',{bubbles:true}));}));render();});
  $$('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());
  root.classList.add('js');
})();
