/* Motion follows meal choices; ordering and status updates remain immediate. */
(() => {
 'use strict';
 const root=document.documentElement,media=matchMedia('(prefers-reduced-motion: reduce)');
 const allowed=()=>!media.matches&&!root.classList.contains('reduce-motion')&&!root.classList.contains('motion-paused')&&!document.hidden;
 const active=new Set(),perElement=new WeakMap(),ghosts=new Set(),menuAnimations=new Set();
 const lowPower=(navigator.deviceMemory!==undefined&&navigator.deviceMemory<=2)||(navigator.deviceMemory===undefined&&navigator.hardwareConcurrency<=4);
 function play(element,frames,options={}){
  if(!element)return null;
  perElement.get(element)?.cancel();
  if(!allowed()||!element?.animate||!element.isConnected)return null;
  const animation=element.animate(frames,{duration:lowPower?200:350,easing:'cubic-bezier(.22,1,.36,1)',...options});
  active.add(animation);perElement.set(element,animation);
  const forget=()=>{active.delete(animation);menuAnimations.delete(animation);if(perElement.get(element)===animation)perElement.delete(element);};
  animation.finished.then(forget,forget);return animation;
 }
 const visible=element=>{const rect=element.getBoundingClientRect();return rect.width>0&&rect.height>0&&rect.bottom>0&&rect.top<innerHeight;};
 // A single owner handles the menu rows, including newly revealed search results.
 const rows=Array.from(document.querySelectorAll('.menu-item')),seen=new WeakSet();let observer=null;
 function enterRows(elements){
  let order=0;
  elements.forEach(element=>{
   if(element.hidden||element.closest('.menu-section')?.hidden||!visible(element))return;
   seen.add(element);observer?.unobserve(element);
   const animation=play(element,[{opacity:.6,translate:'0 8px'},{opacity:1,translate:'0 0'}],{duration:220,delay:lowPower?0:Math.min(order++,5)*18});
   if(animation)menuAnimations.add(animation);
  });
 }
 if(rows.length){
  root.classList.add('menu-motion-owned');
  if('IntersectionObserver' in window){observer=new IntersectionObserver(entries=>enterRows(entries.filter(entry=>entry.isIntersecting&&!seen.has(entry.target)).map(entry=>entry.target)),{threshold:.1});rows.forEach(row=>observer.observe(row));}
 }
 document.addEventListener('antonia:menu-results',event=>{
  menuAnimations.forEach(animation=>animation.cancel());menuAnimations.clear();
  enterRows((event.detail?.revealed||[]).filter(visible).slice(0,12));
  if(event.detail?.empty)play(event.detail.empty,[{opacity:.5,translate:'0 6px'},{opacity:1,translate:'0 0'}],{duration:220});
 });
 // Size and count changes keep the food image in the same visual space.
 document.querySelectorAll('[data-sizer]').forEach(sizer=>{
  const input=sizer.querySelector('[data-sizer-input]'),photo=sizer.querySelector('.sizer-pizza-photo'),label=sizer.querySelector('[data-sizer-inches]');let last=input?.value;
  input?.addEventListener('input',()=>{
   if(input.value===last)return;last=input.value;
   play(photo,[{rotate:'0deg'},{rotate:'-2deg',offset:.4},{rotate:'0deg'}],{duration:lowPower?200:420});
   play(label,[{opacity:.5,translate:'0 -5px'},{opacity:1,translate:'0 0'}],{duration:220});
  });
 });
 document.addEventListener('antonia:party-update',event=>(event.detail?.added||[]).forEach((image,index)=>play(image,[{opacity:0,scale:'.7',rotate:'-8deg'},{opacity:1,scale:'1',rotate:'0deg'}],{duration:280,delay:lowPower?0:Math.min(index,4)*35})));
 // Successful saving leaves a visible trace toward the saved-dishes panel.
 document.addEventListener('antonia:save-change',event=>{
  const badge=document.querySelector('[data-saved-count]');
  play(badge,[{scale:'1'},{scale:'1.2'},{scale:'1'}],{duration:260});
  if(!event.detail?.saved||!allowed())return;
  const source=event.detail.source?.closest('.craving-card')?.querySelector('img'),target=document.querySelector('.saved-dishes');
  if(!source||!target)return;
  const start=source.getBoundingClientRect(),end=target.getBoundingClientRect();
  if(start.width===0||start.bottom<=0||start.top>=innerHeight)return;
  const ghost=document.createElement('img');ghost.src=source.currentSrc||source.src;ghost.alt='';ghost.className='saved-flight';ghost.setAttribute('aria-hidden','true');
  const size=lowPower?56:72,x=start.left+start.width/2-size/2,y=start.top+start.height/2-size/2;
  Object.assign(ghost.style,{left:x+'px',top:y+'px',width:size+'px',height:size+'px'});document.body.append(ghost);ghosts.add(ghost);
  const destinationVisible=end.bottom>0&&end.top<innerHeight;
  const dx=destinationVisible?end.left+Math.min(end.width/2,100)-x:0,dy=destinationVisible?Math.max(24,end.top+24)-y:-24;
  const animation=play(ghost,[{opacity:1,transform:'translate(0,0) scale(1) rotate(0deg)'},{opacity:0,transform:'translate('+dx+'px,'+dy+'px) scale(.35) rotate(12deg)'}],{duration:lowPower?200:550});
  const remove=()=>{ghost.remove();ghosts.delete(ghost);};if(animation)animation.finished.then(remove,remove);else remove();
 });
 // The active marker glides between controls; dimensions update without a layout tween.
 const indicators=[];let frame=0;
 function updateIndicators(instant=false){
  indicators.forEach(state=>{
   const selected=state.host.querySelector(state.selector),box=state.host.getBoundingClientRect(),rect=selected?.getBoundingClientRect();
   if(!rect?.width||!rect.height){state.marker.hidden=true;state.previous=null;return;}
   const next={x:rect.left-box.left+(state.host.scrollLeft||0)-(state.host.clientLeft||0),y:rect.top-box.top+(state.host.scrollTop||0)-(state.host.clientTop||0),width:rect.width,height:rect.height};
   if(state.previous&&Object.keys(next).every(key=>Math.abs(next[key]-state.previous[key])<.5))return;
   state.marker.hidden=false;Object.assign(state.marker.style,{left:next.x+'px',top:next.y+'px',width:next.width+'px',height:next.height+'px'});
   if(state.previous&&!instant){const previous=state.previous;play(state.marker,[{transform:'translate('+(previous.x-next.x)+'px,'+(previous.y-next.y)+'px) scale('+(previous.width/next.width)+','+(previous.height/next.height)+')'},{transform:'translate(0,0) scale(1,1)'}],{duration:lowPower?200:340});}
   else perElement.get(state.marker)?.cancel();
   state.previous=next;
  });
 }
 function queueIndicators(){if(frame)return;frame=requestAnimationFrame(()=>{frame=0;updateIndicators();});}
 document.querySelectorAll('.menu-rail-inner,.craving-filters').forEach(host=>{
  const marker=document.createElement('span');marker.className='selection-indicator';marker.setAttribute('aria-hidden','true');marker.hidden=true;host.prepend(marker);host.classList.add('has-selection-indicator');
  indicators.push({host,marker,previous:null,selector:host.matches('.craving-filters')?'[aria-pressed="true"]':'[aria-current="true"]'});
  if('MutationObserver' in window)new MutationObserver(queueIndicators).observe(host,{subtree:true,attributes:true,attributeFilter:['aria-pressed','aria-current']});
  if('ResizeObserver' in window){const resize=new ResizeObserver(queueIndicators);resize.observe(host);host.querySelectorAll('a,button').forEach(control=>resize.observe(control));}
 });
 updateIndicators(true);addEventListener('resize',queueIndicators,{passive:true});document.fonts?.ready?.then(queueIndicators);
 function stop(){
  if(allowed())return;active.forEach(animation=>animation.cancel());active.clear();menuAnimations.clear();ghosts.forEach(ghost=>ghost.remove());ghosts.clear();
  if(frame){cancelAnimationFrame(frame);frame=0;}updateIndicators(true);
 }
 document.addEventListener('motionchange',stop);document.addEventListener('visibilitychange',stop);media.addEventListener('change',stop);
})();
