/* Approved offers only. Redemption is handled by restaurant staff. */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.AntoniaOffers = factory();
})(typeof window !== 'undefined' ? window : this, function () {
  'use strict';
  const prizes = Object.freeze([
    Object.freeze({ id: 'five-off', title: '$5 OFF', label: '$5 off your order' }),
    Object.freeze({ id: 'ten-percent', title: '10% OFF', label: '10% off your order' }),
    Object.freeze({ id: 'giant-slice', title: 'FREE GIANT SLICE', label: 'One free giant slice' })
  ]);
  function day(date = new Date()) {
    const p = new Intl.DateTimeFormat('en-US', { timeZone: 'America/Los_Angeles', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(date);
    const get = type => p.find(x => x.type === type).value;
    return get('year') + '-' + get('month') + '-' + get('day');
  }
  function create(index, date = new Date()) {
    if (!Number.isInteger(index) || index < 0 || index > 5) throw new RangeError('Invalid offer segment');
    return { version: 2, day: day(date), index, id: prizes[index % 3].id };
  }
  function valid(saved, date = new Date()) {
    return !!saved && saved.version === 2 && saved.day === day(date) && Number.isInteger(saved.index) && saved.index >= 0 && saved.index < 6 && saved.id === prizes[saved.index % 3].id;
  }
  function restore(saved, date = new Date()) {
    if (valid(saved,date)) return saved;
    // Preserve an already-earned $5/10% offer when upgrading the wheel.
    if (saved && saved.version === 1 && saved.day === day(date) && Number.isInteger(saved.index) && saved.index >= 0 && saved.index < 8 && saved.id === prizes[saved.index % 2].id) return create(saved.index % 2,date);
    return null;
  }
  function rotation(index) { return -1800 - (index + 0.5) * 60; }
  function randomIndex() {
    const data=new Uint32Array(1),limit=4294967292;
    do { crypto.getRandomValues(data); } while(data[0]>=limit);
    return data[0]%6;
  }
  return Object.freeze({ prizes, segments:6, day, create, valid, restore, rotation, randomIndex });
});
